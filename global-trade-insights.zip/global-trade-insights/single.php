<?php
/**
 * Single post – Clazar-style article layout.
 * Left: Table of Contents (auto-built from H2/H3 by JS) + author + share.
 * Right: article. Below: Related content.
 */
get_header();

while ( have_posts() ) :
	the_post();

	$share_url   = rawurlencode( get_permalink() );
	$share_title = rawurlencode( get_the_title() );
	$cats        = get_the_category();
	?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<article id="post-<?php the_ID(); ?>" <?php post_class( 'gti-single' ); ?>>

				<!-- Title block -->
				<header class="gti-single__head">
					<p class="gti-single__meta">
						<?php echo esc_html( get_the_date( 'M j, Y' ) ); ?>
						<span class="sep">|</span>
						<span class="gti-read-time"><?php echo esc_html( gti_read_time() ); ?></span>
					</p>
					<h1 class="gti-single__title"><?php the_title(); ?></h1>
					<?php if ( get_the_modified_time( 'U' ) > get_the_time( 'U' ) ) : ?>
						<p class="gti-single__updated">
							<?php esc_html_e( 'Last updated on', 'siteorigin-corp-child' ); ?>
							<b><?php echo esc_html( get_the_modified_date( 'M j, Y' ) ); ?></b>
						</p>
					<?php endif; ?>
				</header>

				<!-- 2-column layout -->
				<div class="gti-single__layout">

					<aside class="gti-single__aside">
						<div class="gti-single__sticky">
							<h4 class="gti-toc__title"><?php esc_html_e( 'Table of Contents', 'siteorigin-corp-child' ); ?></h4>
							<ul class="gti-toc" data-source=".gti-rich-text"></ul>
                         <div class="ontop">
							<div class="gti-single__author">
								<?php echo get_avatar( get_the_author_meta( 'ID' ), 36 ); ?>
								<span><?php the_author(); ?></span>
							</div>

							<p class="gti-share__title"><?php esc_html_e( 'Share', 'siteorigin-corp-child' ); ?></p>
							<div class="gti-share">
								<a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $share_url; ?>" target="_blank" rel="noopener" aria-label="Share on LinkedIn">in</a>
								<a href="https://twitter.com/intent/tweet?url=<?php echo $share_url; ?>&text=<?php echo $share_title; ?>" target="_blank" rel="noopener" aria-label="Share on X">
									<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.9 2H22l-7.5 8.6L23 22h-6.9l-5.4-7-6.2 7H1.4l8-9.2L1 2h7l4.9 6.4L18.9 2Zm-1.2 18h1.9L7.3 3.9H5.3L17.7 20Z"/></svg>
								</a>
								<a href="<?php the_permalink(); ?>" class="gti-copy-link" aria-label="Copy link" data-copied="<?php esc_attr_e( 'Copied!', 'siteorigin-corp-child' ); ?>">
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>
								</a>
							</div>
                            </div>
						</div>
					</aside>

					<div class="gti-single__content">
						<a class="gti-single__back" href="<?php echo esc_url( gti_blog_url() ); ?>">&lt;&lt; <?php esc_html_e( 'Back to all articles', 'siteorigin-corp-child' ); ?></a>

						<?php if ( has_post_thumbnail() ) : ?>
							<div class="gti-single__thumb"><?php the_post_thumbnail( 'large' ); ?></div>
						<?php endif; ?>

						<div class="gti-rich-text entry-content">
							<?php
							the_content();
							wp_link_pages( array( 'before' => '<div class="page-links">', 'after' => '</div>' ) );
							?>
						</div>

						<?php if ( $cats ) : ?>
							<div class="gti-tags">
								<?php foreach ( $cats as $cat ) : ?>
									<a href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>

				</div><!-- .gti-single__layout -->
                <div class="bottom-links">
                							<div class="gti-single__author">
								<?php echo get_avatar( get_the_author_meta( 'ID' ), 36 ); ?>
								<span><?php the_author(); ?></span>
							</div>

							<p class="gti-share__title"><?php esc_html_e( 'Share', 'siteorigin-corp-child' ); ?></p>
							<div class="gti-share">
								<a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $share_url; ?>" target="_blank" rel="noopener" aria-label="Share on LinkedIn">in</a>
								<a href="https://twitter.com/intent/tweet?url=<?php echo $share_url; ?>&text=<?php echo $share_title; ?>" target="_blank" rel="noopener" aria-label="Share on X">
									<svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.9 2H22l-7.5 8.6L23 22h-6.9l-5.4-7-6.2 7H1.4l8-9.2L1 2h7l4.9 6.4L18.9 2Zm-1.2 18h1.9L7.3 3.9H5.3L17.7 20Z"/></svg>
								</a>
								<a href="<?php the_permalink(); ?>" class="gti-copy-link" aria-label="Copy link" data-copied="<?php esc_attr_e( 'Copied!', 'siteorigin-corp-child' ); ?>">
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>
								</a>
							</div>
                </div>
			</article>

			<?php
			/* ---- Related content (same categories, 3 posts) ---- */
			$related = new WP_Query(
				array(
					'post__not_in'        => array( get_the_ID() ),
					'posts_per_page'      => 3,
					'ignore_sticky_posts' => 1,
					'category__in'        => wp_list_pluck( $cats, 'term_id' ),
				)
			);
			if ( ! $related->have_posts() ) {
				$related = new WP_Query( array( 'post__not_in' => array( get_the_ID() ), 'posts_per_page' => 3, 'ignore_sticky_posts' => 1 ) );
			}
			if ( $related->have_posts() ) :
				?>
				<section class="gti-related">
					<div class="gti-container">
						<h2><?php esc_html_e( 'Related content', 'siteorigin-corp-child' ); ?></h2>
						<div class="gti-grid">
							<?php
							while ( $related->have_posts() ) {
								$related->the_post();
								get_template_part( 'template-parts/blog/card' );
							}
							wp_reset_postdata();
							?>
						</div>
					</div>
				</section>
			<?php endif; ?>

			<?php
			if ( comments_open() || get_comments_number() ) {
				echo '<div class="gti-container">';
				comments_template();
				echo '</div>';
			}
			?>

		</main><!-- #main -->
	</div><!-- #primary -->

	<?php
endwhile;

get_footer();