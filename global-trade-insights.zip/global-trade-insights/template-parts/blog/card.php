<?php
/**
 * Blog post card – whole card is the permalink.
 * Used by: home.php, category.php, search.php, single.php (related), AJAX.
 */
?>
<a class="gti-card" href="<?php the_permalink(); ?>" aria-label="<?php the_title_attribute(); ?>">
	<div class="gti-card__media">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?>
		<?php else : ?>
			<div class="gti-card__fallback"><?php the_title(); ?></div>
		<?php endif; ?>
	</div>
	<div class="gti-card__body">
		<div class="gti-card__meta">
			<span><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></span>
			<span><?php echo esc_html( gti_read_time() ); ?></span>
		</div>
		<h3 class="gti-card__title"><?php the_title(); ?></h3>
		<div class="gti-card__author">
			<?php echo get_avatar( get_the_author_meta( 'ID' ), 24 ); ?>
			<span><?php the_author(); ?></span>
		</div>
	</div>
</a>
