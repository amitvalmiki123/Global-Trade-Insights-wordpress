<?php
/**
 * Category tabs + search + posts grid.
 * Works without JS (tabs are real category links, pagination falls back to WP),
 * JS upgrades it to AJAX filtering.
 */
$active_cat  = is_category() ? (int) get_queried_object_id() : 0;
$featured_id = is_home() ? gti_get_featured_post_id() : 0;
$search_q    = is_search() ? get_search_query() : '';

// All categories incl. empty ones (empty → "Nothing found").
$cats = get_categories( array( 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
?>
<section class="gti-listing gti-container"
	data-cat="<?php echo esc_attr( $active_cat ); ?>"
	data-exclude="<?php echo esc_attr( $featured_id ); ?>"
	data-page="1"
	data-max="<?php echo esc_attr( $GLOBALS['wp_query']->max_num_pages ); ?>">

	<!-- Tabs -->
	<div class="gti-tabs-main">
	<div class="gti-tabs">
		<ul class="gti-tabs__list" role="tablist">
			<li class="<?php echo ( ! $active_cat && ! $search_q ) ? 'is-active' : ''; ?>">
				<a href="<?php echo esc_url( gti_blog_url() ); ?>" data-cat="0"><?php esc_html_e( 'All', 'siteorigin-corp-child' ); ?></a>
			</li>
			<?php foreach ( $cats as $cat ) : ?>
				<li class="<?php echo ( $active_cat === (int) $cat->term_id ) ? 'is-active' : ''; ?>">
					<a href="<?php echo esc_url( get_category_link( $cat ) ); ?>" data-cat="<?php echo esc_attr( $cat->term_id ); ?>">
						<?php echo esc_html( $cat->name ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
		<button type="button" class="gti-tabs__search" aria-label="<?php esc_attr_e( 'Search', 'siteorigin-corp-child' ); ?>" aria-expanded="false">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5" stroke-linecap="round"/></svg>
		</button>
	</div>
		<!-- Full-width search bar (slides open) -->
	<div class="gti-search <?php echo $search_q ? 'is-open' : ''; ?>">
		<form class="gti-search__inner" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="search" name="s" value="<?php echo esc_attr( $search_q ); ?>" placeholder="<?php esc_attr_e( 'Search with keyword', 'siteorigin-corp-child' ); ?>" autocomplete="off">
			<button type="button" class="gti-search__clear" aria-label="<?php esc_attr_e( 'Clear search', 'siteorigin-corp-child' ); ?>">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
			</button>
		</form>
	</div>
</div>


	<!-- Grid -->
	<?php
	$has_posts = false;
	ob_start();
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			if ( $featured_id && get_the_ID() === $featured_id ) {
				continue;
			}
			$has_posts = true;
			get_template_part( 'template-parts/blog/card' );
		}
	}
	$grid_html = ob_get_clean();
	?>
	<div class="gti-grid"><?php echo $grid_html; // phpcs:ignore ?></div>

	<div class="gti-empty <?php echo $has_posts ? 'is-hidden' : ''; ?>">
		<h3><?php esc_html_e( 'Nothing found', 'siteorigin-corp-child' ); ?></h3>
	</div>

	<div class="gti-more <?php echo ( $has_posts && $GLOBALS['wp_query']->max_num_pages > 1 ) ? '' : 'is-hidden'; ?>">
		<?php $next = get_next_posts_page_link(); ?>
		<a class="gti-btn gti-more__btn" href="<?php echo $next ? esc_url( $next ) : '#'; ?>"><?php esc_html_e( 'View more', 'siteorigin-corp-child' ); ?></a>
	</div>
</section>