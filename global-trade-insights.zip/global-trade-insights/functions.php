<?php
/**
 * SiteOrigin Corp Child – Global Trade Insights blog
 *
 * Agar aapke existing functions.php me pehle se code hai, to niche wala
 * pura block uske END me paste kar do (opening <?php tag dobara mat likhna).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GTI_CHILD_VERSION', '1.2.0' );

/* -------------------------------------------------------------------------
 * 1. Styles & scripts
 * ---------------------------------------------------------------------- */
add_action( 'wp_enqueue_scripts', 'gti_child_enqueue', 20 );
function gti_child_enqueue() {
	// Parent theme stylesheet.
	wp_enqueue_style( 'siteorigin-corp-style', get_template_directory_uri() . '/style.css', array(), GTI_CHILD_VERSION );

	// Red Hat Display font.
	wp_enqueue_style(
		'gti-fonts',
		'https://fonts.googleapis.com/css2?family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap',
		array(),
		null
	);

	// Child stylesheet (loads after parent + fonts).
	wp_enqueue_style( 'gti-child-style', get_stylesheet_uri(), array( 'siteorigin-corp-style', 'gti-fonts' ), GTI_CHILD_VERSION );

	// Blog JS (header shrink, drawer, tabs, search, TOC).
	wp_enqueue_script( 'gti-blog', get_stylesheet_directory_uri() . '/js/gti-blog.js', array(), GTI_CHILD_VERSION, true );
	wp_localize_script(
		'gti-blog',
		'gtiBlog',
		array(
			'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'gti_blog' ),
			'perPage'  => (int) get_option( 'posts_per_page', 9 ),
			'homeUrl'  => esc_url( home_url( '/' ) ),
			'blogUrl'  => esc_url( gti_blog_url() ),
			'featured' => is_home() ? (int) gti_get_featured_post_id() : 0,
		)
	);
}

/* -------------------------------------------------------------------------
 * 2. Helpers
 * ---------------------------------------------------------------------- */

/** URL of the posts page (or home if posts show on front). */
function gti_blog_url() {
	$page_for_posts = (int) get_option( 'page_for_posts' );
	return $page_for_posts ? get_permalink( $page_for_posts ) : home_url( '/' );
}

/**
 * Real-time read time: words / 200 wpm (calculated from actual content on every load).
 */
function gti_read_time( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return '';
	}
	$text    = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
	$words   = str_word_count( $text );
	$minutes = max( 1, (int) ceil( $words / 200 ) );
	/* translators: %d = minutes */
	return sprintf( _n( '%d min read', '%d min read', $minutes, 'siteorigin-corp-child' ), $minutes );
}

/** Featured post = first sticky post, otherwise the latest post. */
function gti_get_featured_post_id() {
	static $id = null;
	if ( null !== $id ) {
		return $id;
	}
	$sticky = get_option( 'sticky_posts' );
	if ( ! empty( $sticky ) ) {
		$q = new WP_Query( array( 'post__in' => $sticky, 'posts_per_page' => 1, 'ignore_sticky_posts' => 1, 'post_status' => 'publish' ) );
	} else {
		$q = new WP_Query( array( 'posts_per_page' => 1, 'ignore_sticky_posts' => 1, 'post_status' => 'publish' ) );
	}
	$id = $q->have_posts() ? (int) $q->posts[0]->ID : 0;
	wp_reset_postdata();
	return $id;
}

/** Is this one of "our" blog pages? */
function gti_is_blog_listing() {
	return is_home() || is_category() || is_search();
}

/* -------------------------------------------------------------------------
 * 3. Body classes (no sidebar + hooks for CSS)
 * ---------------------------------------------------------------------- */
add_filter( 'body_class', 'gti_body_classes' );
function gti_body_classes( $classes ) {
	if ( gti_is_blog_listing() || is_singular( 'post' ) ) {
		$classes[] = 'gti-blog-page';
		$classes[] = 'no-sidebar';
	}
	if ( is_singular( 'post' ) ) {
		$classes[] = 'gti-single-page';
	}
	return $classes;
}

/* Remove sidebar on blog pages. */
add_filter( 'siteorigin_corp_display_sidebar', 'gti_hide_sidebar' );
function gti_hide_sidebar( $display ) {
	if ( gti_is_blog_listing() || is_singular( 'post' ) ) {
		return false;
	}
	return $display;
}

/* -------------------------------------------------------------------------
 * 4. Blog hero – full width, injected before #content (same design as Clazar)
 * ---------------------------------------------------------------------- */
add_action( 'siteorigin_corp_content_before', 'gti_blog_hero' );
function gti_blog_hero() {
	if ( ! gti_is_blog_listing() ) {
		return;
	}
	$search = is_search() ? get_search_query() : '';

	// Editable via Customizer (GTI Options → Blog Hero).
	$eyebrow   = get_theme_mod( 'gti_hero_eyebrow', __( 'The Global Trade Insights Blog', 'siteorigin-corp-child' ) );
	$heading   = get_theme_mod( 'gti_hero_heading', __( 'Insights and tips to help you trade smarter', 'siteorigin-corp-child' ) );
	$show_form = get_theme_mod( 'gti_hero_show_search', true );
	?>
	<section class="gti-hero">
		<div class="gti-container">
			<?php if ( '' !== $eyebrow ) : ?>
				<p class="gti-hero__eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
			<?php endif; ?>
			<?php if ( '' !== $heading ) : ?>
				<h1 class="gti-hero__title"><?php echo esc_html( $heading ); ?></h1>
			<?php endif; ?>
			<?php if ( $show_form ) : ?>
				<form class="gti-hero__form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search articles', 'siteorigin-corp-child' ); ?>" aria-label="<?php esc_attr_e( 'Search articles', 'siteorigin-corp-child' ); ?>">
					<button type="submit" class="gti-btn gti-btn--light"><?php esc_html_e( 'Search', 'siteorigin-corp-child' ); ?></button>
				</form>
			<?php endif; ?>
		</div>
	</section>
	<?php
}

/* -------------------------------------------------------------------------
 * 5. AJAX – category filter / keyword search / view more
 * ---------------------------------------------------------------------- */
add_action( 'wp_ajax_gti_filter_posts', 'gti_ajax_filter_posts' );
add_action( 'wp_ajax_nopriv_gti_filter_posts', 'gti_ajax_filter_posts' );
function gti_ajax_filter_posts() {
	check_ajax_referer( 'gti_blog', 'nonce' );

	$cat      = isset( $_POST['cat'] ) ? absint( $_POST['cat'] ) : 0;
	$s        = isset( $_POST['s'] ) ? sanitize_text_field( wp_unslash( $_POST['s'] ) ) : '';
	$paged    = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
	$exclude  = isset( $_POST['exclude'] ) ? absint( $_POST['exclude'] ) : 0;

	$args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'paged'               => $paged,
		'posts_per_page'      => (int) get_option( 'posts_per_page', 9 ),
		'ignore_sticky_posts' => 1,
	);
	if ( $cat ) {
		$args['cat'] = $cat;
	}
	if ( '' !== $s ) {
		$args['s'] = $s;
	}
	if ( $exclude ) {
		$args['post__not_in'] = array( $exclude );
	}

	$q = new WP_Query( $args );

	ob_start();
	if ( $q->have_posts() ) {
		while ( $q->have_posts() ) {
			$q->the_post();
			get_template_part( 'template-parts/blog/card' );
		}
	}
	$html = ob_get_clean();
	wp_reset_postdata();

	wp_send_json_success(
		array(
			'html'     => $html,
			'found'    => (int) $q->found_posts,
			'maxPages' => (int) $q->max_num_pages,
			'page'     => $paged,
		)
	);
}

/* -------------------------------------------------------------------------
 * 6. Add IDs to H2 headings inside post content (for Table of Contents)
 * ---------------------------------------------------------------------- */
add_filter( 'the_content', 'gti_add_heading_ids', 20 );
function gti_add_heading_ids( $content ) {
	if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}
	$used = array();
	return preg_replace_callback(
		'/<h2([^>]*)>(.*?)<\/h2>/is',
		function ( $m ) use ( &$used ) {
			if ( preg_match( '/\sid=/', $m[1] ) ) {
				return $m[0];
			}
			$slug = sanitize_title( wp_strip_all_tags( $m[2] ) );
			$base = $slug;
			$i    = 2;
			while ( in_array( $slug, $used, true ) ) {
				$slug = $base . '-' . $i++;
			}
			$used[] = $slug;
			return '<h2' . $m[1] . ' id="' . esc_attr( $slug ) . '">' . $m[2] . '</h2>';
		},
		$content
	);
}

/* -------------------------------------------------------------------------
 * 7. Excerpt tweaks
 * ---------------------------------------------------------------------- */
add_filter( 'excerpt_length', function () { return 24; }, 999 );
add_filter( 'excerpt_more', function () { return '…'; } );

/* -------------------------------------------------------------------------
 * 8. Footer categories bar (below the footer text — "posts ki categories")
 * ---------------------------------------------------------------------- */
function gti_footer_categories() {
	$cats = get_categories( array( 'hide_empty' => true, 'orderby' => 'name', 'order' => 'ASC' ) );
	if ( empty( $cats ) ) {
		return;
	}
	$title = get_theme_mod( 'gti_footer_cats_title', __( 'Categories', 'siteorigin-corp-child' ) );
	?>
	<div class="gti-footer-cats">
		<div class="corp-container">
			<?php if ( '' !== $title ) : ?>
				<h2 class="gti-footer-cats__title"><?php echo esc_html( $title ); ?></h2>
			<?php endif; ?>
			<ul class="gti-footer-cats__list">
				<?php foreach ( $cats as $cat ) : ?>
					<li><a href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * 9. Customizer options – editable hero text + footer categories (GTI Options)
 * ---------------------------------------------------------------------- */
add_action( 'customize_register', 'gti_customize_register' );
function gti_customize_register( $wp_customize ) {

	/* ---- Panel ---- */
	$wp_customize->add_panel(
		'gti_options',
		array(
			'title'    => __( 'GTI Options', 'siteorigin-corp-child' ),
			'priority' => 10,
		)
	);

	/* ---- Section: Blog Hero ---- */
	$wp_customize->add_section(
		'gti_hero',
		array(
			'title'    => __( 'Blog Hero', 'siteorigin-corp-child' ),
			'panel'    => 'gti_options',
			'priority' => 10,
		)
	);

	$wp_customize->add_setting(
		'gti_hero_eyebrow',
		array(
			'default'           => __( 'The Global Trade Insights Blog', 'siteorigin-corp-child' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'gti_hero_eyebrow',
		array(
			'label'   => __( 'Hero Eyebrow', 'siteorigin-corp-child' ),
			'section' => 'gti_hero',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'gti_hero_heading',
		array(
			'default'           => __( 'Insights and tips to help you trade smarter', 'siteorigin-corp-child' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'gti_hero_heading',
		array(
			'label'   => __( 'Hero Heading', 'siteorigin-corp-child' ),
			'section' => 'gti_hero',
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'gti_hero_show_search',
		array(
			'default'           => true,
			'sanitize_callback' => 'gti_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'gti_hero_show_search',
		array(
			'label'   => __( 'Show search bar in hero', 'siteorigin-corp-child' ),
			'section' => 'gti_hero',
			'type'    => 'checkbox',
		)
	);

	/* ---- Section: Footer Categories ---- */
	$wp_customize->add_section(
		'gti_footer_cats',
		array(
			'title'    => __( 'Footer Categories', 'siteorigin-corp-child' ),
			'panel'    => 'gti_options',
			'priority' => 20,
		)
	);

	$wp_customize->add_setting(
		'gti_footer_cats_title',
		array(
			'default'           => __( 'Categories', 'siteorigin-corp-child' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'gti_footer_cats_title',
		array(
			'label'       => __( 'Footer Categories Title', 'siteorigin-corp-child' ),
			'description' => __( 'Categories ki list dekhegi footer me (title blank karo to heading hide ho jayegi).', 'siteorigin-corp-child' ),
			'section'     => 'gti_footer_cats',
			'type'        => 'text',
		)
	);
}

/**
 * Sanitize checkbox value to true/false.
 */
function gti_sanitize_checkbox( $checked ) {
	return ( isset( $checked ) && true == $checked ) ? true : false;
}
