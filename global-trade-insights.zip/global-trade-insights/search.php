<?php
/**
 * Search results – same listing, search bar pre-filled and open.
 */
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">
		<?php get_template_part( 'template-parts/blog/listing' ); ?>
	</main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
