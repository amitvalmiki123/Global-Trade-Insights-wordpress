/**
 * Global Trade Insights – blog JS (vanilla, no jQuery needed)
 * 1. Sticky header shrink
 * 2. Modern slide-in hamburger drawer (uses Corp's #mobile-menu-button + #primary-menu)
 * 3. Category tabs + full-width search + View more (AJAX)
 * 4. Single post: Table of Contents + scroll-spy + copy link
 */
(function () {
  'use strict';

  var cfg = window.gtiBlog || {};
  var body = document.body;

  /* ------------------------------------------------------------------
   * 1. HEADER SHRINK ON SCROLL
   * ---------------------------------------------------------------- */
  function onScroll() {
    body.classList.toggle('gti-scrolled', window.scrollY > 40);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ------------------------------------------------------------------
   * 2. HAMBURGER DRAWER
   * ---------------------------------------------------------------- */
  (function initDrawer() {
    var btn = document.getElementById('mobile-menu-button');
    var menu = document.getElementById('primary-menu');
    if (!btn || !menu) return;

    // Kill Corp's default click handler by replacing the button node.
    var clone = btn.cloneNode(false);
    clone.removeAttribute('href');
    clone.setAttribute('role', 'button');
    clone.setAttribute('tabindex', '0');
    clone.setAttribute('aria-label', 'Open menu');
    clone.setAttribute('aria-expanded', 'false');
    clone.innerHTML = '<span class="gti-burger"><span></span><span></span><span></span></span>';
    btn.parentNode.replaceChild(clone, btn);
    btn = clone;

    // Build overlay + drawer
    var overlay = document.createElement('div');
    overlay.className = 'gti-drawer-overlay';

    var drawer = document.createElement('aside');
    drawer.className = 'gti-drawer';
    drawer.setAttribute('aria-hidden', 'true');

    var branding = document.querySelector('#masthead .site-branding');
    var brandingHTML = branding ? '<div class="site-branding">' + branding.innerHTML + '</div>' : '';

    drawer.innerHTML =
      '<div class="gti-drawer__head">' +
        brandingHTML +
        '<button type="button" class="gti-drawer__close" aria-label="Close menu">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>' +
        '</button>' +
      '</div>' +
      '<nav class="gti-drawer__nav" aria-label="Mobile menu"></nav>' +
      '<div class="gti-drawer__foot">' +
        '<form role="search" method="get" action="' + (cfg.homeUrl || '/') + '">' +
          '<input type="search" name="s" placeholder="Search…" aria-label="Search">' +
          '<button type="submit" aria-label="Search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5" stroke-linecap="round"/></svg></button>' +
        '</form>' +
        '<p class="gti-drawer__copy">© ' + new Date().getFullYear() + ' Global Trade Insights</p>' +
      '</div>';

    var nav = drawer.querySelector('.gti-drawer__nav');
    var menuClone = menu.cloneNode(true);
    menuClone.removeAttribute('id');
    nav.appendChild(menuClone);

    // Staggered link animation
    nav.querySelectorAll('a').forEach(function (a, i) {
      a.style.transitionDelay = (80 + i * 50) + 'ms';
    });

    body.appendChild(overlay);
    body.appendChild(drawer);

    function open() {
      body.classList.add('gti-drawer-open');
      drawer.setAttribute('aria-hidden', 'false');
      btn.setAttribute('aria-expanded', 'true');
    }
    function close() {
      body.classList.remove('gti-drawer-open');
      drawer.setAttribute('aria-hidden', 'true');
      btn.setAttribute('aria-expanded', 'false');
      nav.querySelectorAll('a').forEach(function (a) { a.style.transitionDelay = '0ms'; });
      setTimeout(function () {
        nav.querySelectorAll('a').forEach(function (a, i) { a.style.transitionDelay = (80 + i * 50) + 'ms'; });
      }, 400);
    }
    function toggle(e) {
      if (e) { e.preventDefault(); e.stopImmediatePropagation(); }
      body.classList.contains('gti-drawer-open') ? close() : open();
    }

    btn.addEventListener('click', toggle, true);
    btn.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') toggle(e); });
    overlay.addEventListener('click', close);
    drawer.querySelector('.gti-drawer__close').addEventListener('click', close);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    window.addEventListener('resize', function () { if (window.innerWidth > 768) close(); });
  })();

  /* ------------------------------------------------------------------
   * 3. LISTING: TABS + INLINE SEARCH + VIEW MORE (AJAX)
   * ---------------------------------------------------------------- */
  (function initListing() {
    var root = document.querySelector('.gti-listing');
    if (!root || !cfg.ajaxUrl) return;

    var tabsRow      = root.querySelector('.gti-tabs');
    var tabs         = root.querySelectorAll('.gti-tabs__list li');
    var searchToggle = root.querySelector('.gti-tabs__search');
    var searchWrap   = root.querySelector('.gti-search');
    var searchInput  = root.querySelector('.gti-search input[type="search"]');
    var searchClear  = root.querySelector('.gti-search__clear');
    var searchForm   = root.querySelector('.gti-search form');
    var grid         = root.querySelector('.gti-grid');
    var empty        = root.querySelector('.gti-empty');
    var more         = root.querySelector('.gti-more');
    var moreBtn      = root.querySelector('.gti-more__btn');

    var state = {
      cat:     parseInt(root.dataset.cat || '0', 10),
      s:       searchInput ? searchInput.value.trim() : '',
      page:    parseInt(root.dataset.page || '1', 10),
      max:     parseInt(root.dataset.max || '1', 10),
      exclude: parseInt(root.dataset.exclude || '0', 10)
    };
    var reqId = 0;
    var timer;

    // Search page pe pre-open
    if (searchWrap && searchWrap.classList.contains('is-open')) tabsRow.classList.add('is-searching');

    function request(append) {
      var id = ++reqId;
      var page = append ? state.page + 1 : 1;
      grid.classList.add('is-loading');

      var data = new FormData();
      data.append('action', 'gti_filter_posts');
      data.append('nonce', cfg.nonce);
      data.append('cat', state.cat);
      data.append('s', state.s);
      data.append('page', page);
      data.append('exclude', (!state.cat && !state.s) ? state.exclude : 0);

      fetch(cfg.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (id !== reqId || !res || !res.success) return;
          var d = res.data;
          if (append) grid.insertAdjacentHTML('beforeend', d.html);
          else grid.innerHTML = d.html;
          state.page = d.page;
          state.max  = d.maxPages;
          var hasPosts = grid.children.length > 0;
          empty.classList.toggle('is-hidden', hasPosts);
          more.classList.toggle('is-hidden', !hasPosts || state.page >= state.max);
        })
        .catch(function () {})
        .finally(function () { grid.classList.remove('is-loading'); });
    }

    // Tabs
    tabs.forEach(function (li) {
      var a = li.querySelector('a');
      if (!a) return;
      a.addEventListener('click', function (e) {
        e.preventDefault();
        tabs.forEach(function (t) { t.classList.remove('is-active'); });
        li.classList.add('is-active');
        state.cat = parseInt(a.dataset.cat || '0', 10);
        if (window.history && history.replaceState) history.replaceState(null, '', a.href);
        request(false);
      });
    });

    // Search toggle
    if (searchToggle && searchWrap) {
      searchToggle.addEventListener('click', function () {
        var isOpen = searchWrap.classList.toggle('is-open');
        tabsRow.classList.toggle('is-searching', isOpen);
        searchToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        if (isOpen && searchInput) setTimeout(function () { searchInput.focus(); }, 200);
      });
    }

    // Live search
    if (searchInput) {
      searchInput.addEventListener('input', function () {
        clearTimeout(timer);
        timer = setTimeout(function () {
          state.s = searchInput.value.trim();
          request(false);
        }, 350);
      });
    }
    if (searchForm) {
      searchForm.addEventListener('submit', function (e) {
        e.preventDefault();
        clearTimeout(timer);
        state.s = searchInput ? searchInput.value.trim() : '';
        request(false);
      });
    }

    // ✕ clear + close
    if (searchClear) {
      searchClear.addEventListener('click', function () {
        if (searchInput) searchInput.value = '';
        searchWrap.classList.remove('is-open');
        tabsRow.classList.remove('is-searching');
        searchToggle && searchToggle.setAttribute('aria-expanded', 'false');
        if (state.s !== '') { state.s = ''; request(false); }
      });
    }

    // View more
    if (moreBtn) {
      moreBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (state.page < state.max) request(true);
      });
    }
  })();
  /* ------------------------------------------------------------------
   * 4. SINGLE: TABLE OF CONTENTS + SCROLL-SPY + COPY LINK
   * ---------------------------------------------------------------- */
  (function initToc() {
    var toc = document.querySelector('.gti-toc');
    if (!toc) return;
    var source = document.querySelector(toc.dataset.source || '.gti-rich-text');
    if (!source) return;

    var headings = Array.prototype.slice.call(source.querySelectorAll('h2'));
    if (!headings.length) {
      var t = document.querySelector('.gti-toc__title');
      if (t) t.style.display = 'none';
      return;
    }

    var items = [];
    headings.forEach(function (h, i) {
      if (!h.id) h.id = 'section-' + (i + 1);
      var li = document.createElement('li');
      var a = document.createElement('a');
      a.href = '#' + h.id;
      a.textContent = h.textContent.trim();
      li.appendChild(a);
      toc.appendChild(li);
      items.push({ h: h, li: li });
      a.addEventListener('click', function (e) {
        e.preventDefault();
        var top = h.getBoundingClientRect().top + window.scrollY - 100;
        window.scrollTo({ top: top, behavior: 'smooth' });
        history.replaceState(null, '', '#' + h.id);
      });
    });
    items[0].li.classList.add('is-active');

    if ('IntersectionObserver' in window) {
      var obs = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          items.forEach(function (it) { it.li.classList.toggle('is-active', it.h === en.target); });
        });
      }, { rootMargin: '-20% 0px -70% 0px' });
      headings.forEach(function (h) { obs.observe(h); });
    }

    // Copy link
    var copy = document.querySelector('.gti-copy-link');
    if (copy && navigator.clipboard) {
      copy.addEventListener('click', function (e) {
        e.preventDefault();
        navigator.clipboard.writeText(copy.href).then(function () {
          var old = copy.innerHTML;
          copy.textContent = '✓';
          setTimeout(function () { copy.innerHTML = old; }, 1500);
        });
      });
    }
  })();
})();