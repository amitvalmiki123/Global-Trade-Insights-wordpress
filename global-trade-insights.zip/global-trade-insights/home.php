<?php
/**
 * Blog posts page (Settings → Reading → Posts page).
 * Hero is printed by gti_blog_hero() via the siteorigin_corp_content_before hook.
 */
get_header();

$featured_id = gti_get_featured_post_id();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">

		<?php if ( $featured_id ) : ?>
			<?php $featured = get_post( $featured_id ); ?>
			<div class="gti-container">
				<a class="gti-featured" href="<?php echo esc_url( get_permalink( $featured ) ); ?>">
					<div class="gti-featured__body">
						<span class="gti-card__meta"><?php echo esc_html( gti_read_time( $featured ) ); ?></span>
						<h2 class="gti-featured__title"><?php echo esc_html( get_the_title( $featured ) ); ?></h2>
						<div class="gti-featured__meta">
							<?php echo get_avatar( $featured->post_author, 36 ); ?>
							<span><?php echo esc_html( get_the_author_meta( 'display_name', $featured->post_author ) ); ?></span>
							<span class="sep"></span>
							<span><?php echo esc_html( get_the_date( 'F j, Y', $featured ) ); ?></span>
						</div>
					</div>
					<div class="gti-featured__media">
						<?php if ( has_post_thumbnail( $featured ) ) : ?>
							<?php echo get_the_post_thumbnail( $featured, 'large' ); ?>
						<?php else : ?>
							<div class="gti-card__fallback" style="font-size:34px"><?php echo esc_html( get_the_title( $featured ) ); ?></div>
						<?php endif; ?>
					</div>
				</a>
			</div>
		<?php endif; ?>

		<?php get_template_part( 'template-parts/blog/listing' ); ?>

	</main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
