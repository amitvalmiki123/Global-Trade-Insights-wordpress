<?php
/**
 * Category archive – same listing with the category tab pre-selected.
 * Shows "Nothing found" if the category has no posts.
 */
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main">
		<?php get_template_part( 'template-parts/blog/listing' ); ?>
	</main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
