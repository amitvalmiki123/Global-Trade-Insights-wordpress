# SiteOrigin Corp Child – Global Trade Insights Blog

Clazar-style blog design for your existing **SiteOrigin Corp** child theme.
Header aur footer aapke existing hi rahenge — sirf blog listing, single post, aur mobile menu upgrade hota hai.

## Files (copy to `wp-content/themes/siteorigin-corp-child/`)

```
siteorigin-corp-child/
├── style.css                        ← REPLACE (ya apne existing style.css ke END me paste karo, header comment chhod ke)
├── functions.php                    ← REPLACE (ya existing functions.php ke END me paste karo, <?php dobara mat likhna)
├── home.php                         ← NEW  (blog listing page)
├── category.php                     ← NEW  (category archive – "Nothing found" if empty)
├── search.php                       ← NEW  (search results)
├── single.php                       ← NEW  (single blog post with TOC)
├── js/
│   └── gti-blog.js                  ← NEW
└── template-parts/
    └── blog/
        ├── card.php                 ← NEW  (post card – full card is a link)
        └── listing.php              ← NEW  (tabs + search + grid)
```

## Install steps

1. **WP File Manager / FTP** se `wp-content/themes/siteorigin-corp-child/` kholo.
2. Upar wali files upload karo (same folder structure me).
   - Agar `style.css` / `functions.php` me pehle se aapka code hai → us file ka content **append** karo, replace mat karo.
3. **Settings → Reading** → "Your homepage displays" = *A static page* → **Posts page** = Blog page select karo (tabhi `home.php` chalega).
4. **Appearance → Customize → Theme Settings → Header** → *Sticky header* ON kar do (shrink effect ke liye).
5. **Appearance → Customize → Theme Settings → Navigation** → *Mobile menu* ON rakho (hamburger button wahi se aata hai; hamara JS use modern drawer bana deta hai).
6. Featured post chahiye to kisi post ko **Stick to the top of the blog** karo, warna latest post featured banta hai.
7. Cache clear karo (LiteSpeed/WP Rocket/Hostinger cache).

## Kya-kya milta hai

| Feature | Kaise |
|---|---|
| Font Red Hat Display | `functions.php` me Google Fonts enqueue + `style.css` me `!important` override |
| Navy colors (no orange) | CSS variables `--gti-navy-*` |
| Read time (real-time) | `gti_read_time()` – har load pe word count ÷ 200 wpm |
| Full card clickable | `template-parts/blog/card.php` – `<a class="gti-card">` |
| Category tabs (aapki WP categories) | `get_categories( hide_empty => false )` – khali category = **Nothing found** |
| Full-width search with ✕ | tabs ke right icon se slide-open, live AJAX filter |
| View more | AJAX pagination (`gti_filter_posts`) |
| Sticky shrink header | `body.gti-scrolled` class on scroll > 40px |
| Mobile drawer with ✕ | Corp ka `#mobile-menu-button` + `#primary-menu` clone → slide-in drawer |
| Single post TOC + scroll-spy | H2 headings se auto-generate (`gti_add_heading_ids`) |
| No AI Summary / No guide card | removed |

## Customize

- Hero text: `functions.php` → `gti_blog_hero()`
- Posts per page: **Settings → Reading → Blog pages show at most**
- Colors/fonts: `style.css` → `:root` tokens
- Logo size: `style.css` → `#masthead .site-branding img { max-height }` (normal 44px / scrolled 32px)
